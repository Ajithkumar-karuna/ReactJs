import React from "react";
   
export function Action(){
    return(
      <>
         <marquee><h1 className="mt-5 display-1 text-dark">"Hello World"</h1></marquee> 
      </>
    );
}
