import React from "react";
import './task2.css';
 export function Congrats(){
    return(
        <>
       <div className="images">
               
       <div class="card4">
  <div class="card-body">
    <h2 class="card-title text-center mr-1">Congratulation</h2>
   </div>
</div>  
<div className="container-fluid d-flex justify-content-center">          
             <div className="back-bg  text-center ">

                <img src="https://assets.ccbp.in/frontend/react-js/congrats-card-profile-img.png" className="pt-3" />
                <h1 className="head2">Kiran.v</h1>
                <h5 className="head6 pt-3">vishnu institute of computer education and technology.bhemavaram </h5>
                <img src="https://assets.ccbp.in/frontend/react-js/congrats-card-watch-img.png" className=" pt-5" />
            </div>
            </div>

              </div>
              
      
     </>
    );
}
